#!/usr/bin/python

import sys
import searchbuilder

searchbuilder.Search("test ","audio").get_kat_results()
